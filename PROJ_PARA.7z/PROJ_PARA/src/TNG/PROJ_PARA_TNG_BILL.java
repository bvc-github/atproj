package TNG;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PROJ_PARA_TNG_BILL {
	WebDriver driver;
	@BeforeMethod
	public void beforemethod() {
		System.setProperty("webdriver.chrome.driver","C:\\software\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.get("http://demowebshop.tricentis.com/login");
		driver.findElement(By.id("Email")).sendKeys("sidwagh11@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("sidwagh");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

		driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		List<WebElement> element=driver.findElements(By.id("termsofservice"));
		element.get(0).click();
		driver.findElement(By.name("checkout")).click();
		
		Select newaddress=new Select(driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]")));
		newaddress.selectByVisibleText("New Address");
		}
	/*	
	}
  @Test
  @Parameters({"username","password"})
  public void ParamTest(String username,String password) throws Exception
  {
  	WebElement user=driver.findElement(By.name("username"));
  	user.sendKeys(username);
  	
  	driver.findElement(By.id("pwd")).sendKeys(password);
  	
  	//driver.findElement(By.xpath("//*[@id=\"loginform\"]/input[3]\n")).click();
  }
}
*/
	@Test(dataProvider="bill_address")
		public void dataProviderTest(String  Company,String Country,String City,String Address1,String Address2,String zipcode,String phone,String fax_no) throws InterruptedException
		{
	 	/*WebElement FN=driver.findElement(By.id("BillingNewAddress_FirstName"));
	 	FN.sendKeys(FirstName);
	 	System.out.println("1");
	    Thread.sleep(1000);
	    
	 	WebElement LN=driver.findElement(By.id("BillingNewAddress_LastName"));
	 	LN.sendKeys(LastName);
	 	System.out.println("2");
	    Thread.sleep(1000);
	    
	 	WebElement email=driver.findElement(By.id("BillingNewAddress_Email"));
	 	email.sendKeys(Email);
	 	System.out.println("3");
	    Thread.sleep(1000);
	    */
	 	WebElement comp=driver.findElement(By.id("BillingNewAddress_Company"));
	  	comp.sendKeys(Company);
	 	System.out.println("4");
	    Thread.sleep(1000);
	    
	    
		Select sCountry=new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
		sCountry.selectByVisibleText(Country);
	    
		Select sState=new Select(driver.findElement(By.id("BillingNewAddress_StateProvinceId")));
		sState.selectByIndex(0);
		
	 	WebElement bnaCity=driver.findElement(By.id("BillingNewAddress_City"));
	  	bnaCity.sendKeys(City);
		
	  	WebElement add_1=driver.findElement(By.id("BillingNewAddress_Address1"));
	  	add_1.sendKeys(Address1);
	  	
	  	WebElement add_2=driver.findElement(By.id("BillingNewAddress_Address2"));
	  	add_2.sendKeys(Address2);
	  	
		WebElement zcode=driver.findElement(By.id("BillingNewAddress_ZipPostalCode"));
	  	zcode.sendKeys(zipcode);
	  	
	  	WebElement phoneno=driver.findElement(By.id("BillingNewAddress_PhoneNumber"));
	  	phoneno.sendKeys(phone);
	  	
	  	WebElement faxno=driver.findElement(By.id("BillingNewAddress_FaxNumber"));
	  	faxno.sendKeys(fax_no);
	  	
	  	driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
	  	
	  	Thread.sleep(10000);
	  	System.out.println("7");
	  	
	  	driver.close();
		}
	@DataProvider(name="bill_address")
	public Object[][] dataFromXml()
	{
		return new Object[][] {
		new Object[] {"Company1","Select country","city1","address1","address2","849273","3479234729","3537252-46442"},
		new Object[] {"Company2","India","","address1","address2","849273","9086549754","3saaf252-46442"},
		new Object[] {"Company3","Austria","city3","","address2","849273","3479234729",""},
		new Object[] {"Company4","Canada","city4","address1","address2","","9988776655","3537252-46442"},
		new Object[] {"Company4","India","city5","address1","address2","849273","","3537252-46442"},
		new Object[] {"Company4","India","city6","address1","address2","849273","9845776835","3537252-46442"},
	};
	}
}
	